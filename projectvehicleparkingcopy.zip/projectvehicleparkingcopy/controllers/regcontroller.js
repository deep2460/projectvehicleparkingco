const Reg=require('../models/reg')
const bcrypt=require('bcrypt')


exports.loginpage=(req,res)=>{
    res.render('login.ejs',{message:''})
}

exports.regpage=(req,res)=>{
    res.render('regform.ejs',{message:''})
}
exports.register=async(req,res)=>{
    //console.log(req.body)
    const{us,pass}=req.body
    const usercheck=await Reg.findOne({username:us})
    //console.log(usercheck)
    if(usercheck==null){
    const convertedpass=await bcrypt.hash(pass,10)
    const record=new Reg({username:us,password:convertedpass})
    record.save()
    //console.log(record)
    res.render('regform.ejs',{message:`${us} hasbeen successfully registered`})
    }else{
        res.render('regform.ejs',{message:`${us} username already registered`})
    }
}
exports.logincheck=async(req,res)=>{
    //console.log(req.body)
    const{username,password}=req.body
   const record= await Reg.findOne({username:username})
   //console.log(record)
   if(record!==null){
    const passwordcomapre=await bcrypt.compare(password,record.password)
    //console.log(passwordcomapre)
    if(passwordcomapre){
        req.session.isAuth=true
        req.session.loginname=username
      res.redirect('/parking')
    }else{
        res.render('login.ejs',{message:'wrong password'})
    }
   }else{
    res.render('login.ejs',{message:'wrong username'})
   }
}



exports.logout=(req,res)=>{
    req.session.destroy()
    res.redirect('/')
}



