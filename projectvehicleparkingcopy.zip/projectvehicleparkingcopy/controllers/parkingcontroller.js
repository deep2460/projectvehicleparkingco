const Parking=require('../models/parking')




exports.parkingpage=async(req,res)=>{
    //console.log(req.session)
    const loginname=req.session.loginname
    const record=await Parking.find()
    //console.log(record)
    res.render('parking.ejs',{loginname,record})
}
exports.parkingaddform=(req,res)=>{
    const loginname=req.session.loginname
    res.render('parkingform.ejs',{loginname,message:''})
}

exports.parkingaddvehicle=(req,res)=>{
    //console.log(req.body)
    const {vno,vtype}=req.body
    const loginname=req.session.loginname
    let vintime= new Date()
    //console.log(intime)
    const record=new Parking({vno:vno, vtype:vtype, vin:vintime,})
    record.save()
    //console.log(record)
    res.render('parkingform.ejs',{loginname,message:'Parking vehicle added successfully'})
}

exports.parkingupdate=async(req,res)=>{
    //console.log(req.params.id)
    const id=req.params.id
    let voutTime=new Date()
    const record=await Parking.findById(id)
    //console.log(record)
    let consumedTime=(voutTime-record.vin)/(1000*60*60)//mili sec convert into hour
    //console.log(consumedTime)
    let amount=null
    if(record.vtype=='2w'){
        amount=consumedTime*30
    }else if(record.vtype=='3w'){
        amount=consumedTime*50
    }else if(record.vtype=='4'){
        amount=consumedTime*80
    }else if(record.vtype=='lv'){
        amount=consumedTime*100
    }else if(record.vtype=='hv'){
        amount=consumedTime*120
    }else{
        amount=consumedTime*60
    }
    await Parking.findByIdAndUpdate(id,{vout:voutTime,amount:Math.round(amount),status:'OUT'})
    res.redirect('/parking')
}

exports.waytoprint=async(req,res)=>{
    //console.log(req.params.id)
    const id=req.params.id
    const record=await Parking.findById(id)
    res.render('printpage.ejs',{record})
}